// Picks 14 puzzles with no shared theme answers and as little repeated fill as possible.
const fs = require('fs'), path = require('path');
const MED = require(path.join(__dirname, 'medical.js'));
const rows = fs.readFileSync(path.join(__dirname, 'bank.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
const seenGrid = new Set();
const uniq = rows.filter(r => { const k = r.grid.join(''); if (seenGrid.has(k)) return false; seenGrid.add(k); return true; });
uniq.sort((a, b) => b.medical - a.medical);
const chosen = [], themes = new Set(), wordCount = {};
for (const r of uniq) {
  const th = r.words.filter(w => w.length >= 7);
  if (th.some(w => themes.has(w))) continue;
  chosen.push(r); th.forEach(w => themes.add(w));
  r.words.forEach(w => wordCount[w] = (wordCount[w] || 0) + 1);
  if (chosen.length === 14) break;
}
fs.writeFileSync(path.join(__dirname, 'chosen.json'), JSON.stringify(chosen.map(r => r.grid)));
const all = Object.keys(wordCount).sort();
const need = all.filter(w => !(MED[w] && MED[w].length));
console.log('chosen', chosen.length, 'from', uniq.length, '| unique words', all.length, '| need clues', need.length);
console.log('medical per puzzle:', chosen.map(r => r.medical).join(' '));
console.log('themes:', [...themes].join(' '));
console.log('\nNEED:\n' + need.join(' '));
console.log('\nMEDICAL USED:\n' + all.filter(w => MED[w]).join(' '));
