// Builds 11x11 American-style crosswords: symmetric black squares, every white square in an
// across and a down answer, all answers 3+ letters. Fills only from our own word lists.
// Usage: node gen.js <count> <seed> > puzzles.json
const path = require('path');
const XW = __dirname;
const MED = require(path.join(process.argv[4] || XW, 'medical.js'));
const GEN = require(path.join(process.argv[4] || XW, 'general.js'));
const GEN7 = process.env.GEN7 ? require(path.join(XW, 'general7.js')) : [];

const N = +(process.env.N || 11);
const LONGMIN = +(process.env.LONGMIN || 8), LONGLO = +(process.env.LONGLO || 2), LONGHI = +(process.env.LONGHI || 4), SEVENMAX = +(process.env.SEVENMAX || 4), MAXRUN = +(process.env.MAXRUN || N);
let seed = +(process.argv[3] || 7);
const rnd = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

const medWords = Object.keys(MED).filter(w => /^[A-Z]+$/.test(w) && MED[w]);
const medSet = new Set(medWords);
const all = [...new Set([...medWords, ...GEN, ...GEN7])].filter(w => w.length >= 3 && w.length <= N);
const byLen = {};
all.forEach(w => (byLen[w.length] = byLen[w.length] || []).push(w));

// ---------- templates ----------
function runs(g){
  const out = [];
  for (let r = 0; r < N; r++) { let c = 0; while (c < N) { if (g[r][c]) { c++; continue; } let s = c; while (c < N && !g[r][c]) c++; out.push({ dir:'a', r, c:s, len:c - s }); } }
  for (let c = 0; c < N; c++) { let r = 0; while (r < N) { if (g[r][c]) { r++; continue; } let s = r; while (r < N && !g[r][c]) r++; out.push({ dir:'d', r:s, c, len:r - s }); } }
  return out;
}
function connected(g){
  let start = null, white = 0;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!g[r][c]) { white++; if (!start) start = [r, c]; }
  const seen = new Set([start.join()]), q = [start];
  while (q.length) { const [r, c] = q.pop(); [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dr,dc]) => { const R = r+dr, C = c+dc; if (R>=0&&R<N&&C>=0&&C<N&&!g[R][C]&&!seen.has(R+','+C)) { seen.add(R+','+C); q.push([R,C]); } }); }
  return seen.size === white;
}
function makeTemplate(minBlack, maxBlack){
  for (let tries = 0; tries < 20000; tries++){
    const g = [...Array(N)].map(() => Array(N).fill(false));
    const target = minBlack + Math.floor(rnd() * (maxBlack - minBlack + 1));
    let black = 0, guard = 0;
    while (black < target && guard++ < 400) {
      const r = Math.floor(rnd() * N), c = Math.floor(rnd() * N);
      if (g[r][c]) continue;
      g[r][c] = g[N-1-r][N-1-c] = true;
      black += (r === N-1-r && c === N-1-c) ? 1 : 2;
      const bad = runs(g).some(x => x.len < 3);
      if (bad) { g[r][c] = g[N-1-r][N-1-c] = false; black -= (r === N-1-r && c === N-1-c) ? 1 : 2; }
    }
    if (black < minBlack) continue;
    const rs = runs(g);
    if (rs.some(x => x.len < 3)) continue;
    const long = rs.filter(x => x.len >= LONGMIN).length, seven = rs.filter(x => x.len === 7 && 7 < LONGMIN).length;
    if (long < LONGLO || long > LONGHI || seven > SEVENMAX) continue;
    if (rs.some(x => x.len > MAXRUN)) continue;
    if (!connected(g)) continue;
    // looks like a real puzzle: black squares spread out, no clumps
    const MAXROW = +(process.env.MAXROW || 6);
    if (g.some(row => row.filter(Boolean).length > MAXROW)) continue;
    if ([...Array(N)].some((_, c) => g.filter(row => row[c]).length > MAXROW)) continue;
    let clump = false;
    for (let r = 0; r < N-1; r++) for (let c = 0; c < N-1; c++) if (g[r][c] && g[r+1][c] && g[r][c+1] && g[r+1][c+1]) clump = true;
    if (clump) continue;
    return g;
  }
  return null;
}

// ---------- filler ----------
function fill(g, banned, deadline){
  const slots = runs(g).map((s, i) => ({ ...s, i, cells: [...Array(s.len)].map((_, k) => s.dir === 'a' ? [s.r, s.c + k] : [s.r + k, s.c]) }));
  const cellSlots = {};
  slots.forEach(s => s.cells.forEach(([r,c], k) => (cellSlots[r+','+c] = cellSlots[r+','+c] || []).push([s.i, k])));
  const letters = [...Array(N)].map(() => Array(N).fill(null));
  const assign = Array(slots.length).fill(null), used = new Set();
  // index: for each pool, position -> letter -> words, so a pattern lookup intersects small lists
  const poolCache = {};
  const getPool = len => {
    const key = len >= 7 ? 'm' + len : 'g' + len;
    if (poolCache[key]) return poolCache[key];
    const words = len >= 7 && !(GEN7.length && len === 7) ? (byLen[len] || []).filter(w => medSet.has(w) && !banned.has(w)) : (byLen[len] || []).filter(w => !banned.has(w));
    const idx = [...Array(len)].map(() => ({}));
    words.forEach(w => { for (let k = 0; k < len; k++) (idx[k][w[k]] = idx[k][w[k]] || []).push(w); });
    return poolCache[key] = { words, idx };
  };
  const pools = slots.map(s => getPool(s.len));
  const pattern = s => s.cells.map(([r,c]) => letters[r][c]);
  const matches = (w, p) => { for (let k = 0; k < p.length; k++) if (p[k] && p[k] !== w[k]) return false; return true; };
  const cands = s => {
    const p = pattern(s), pool = pools[s.i];
    let base = pool.words;
    for (let k = 0; k < p.length; k++) if (p[k]) { const l = pool.idx[k][p[k]] || []; if (l.length < base.length) base = l; }
    return base.filter(w => !used.has(w) && matches(w, p));
  };
  let steps = 0;
  function solve(){
    if (Date.now() > deadline) return false;
    let best = null, bestC = null;
    for (const s of slots) {
      if (assign[s.i]) continue;
      const c = cands(s);
      if (!c.length) return false;
      if (!best || c.length < bestC.length) { best = s; bestC = c; if (c.length === 1) break; }
    }
    if (!best) return true;
    // prefer medical words, then random
    const ordered = shuffle(bestC.slice()).sort((a, b) => (medSet.has(b) ? 1 : 0) - (medSet.has(a) ? 1 : 0) + (rnd() - .5) * 0.6).slice(0, 40);
    for (const w of ordered) {
      steps++;
      const prev = best.cells.map(([r,c]) => letters[r][c]);
      best.cells.forEach(([r,c], k) => letters[r][c] = w[k]);
      assign[best.i] = w; used.add(w);
      // forward check crossing slots
      let ok = true;
      for (const [r,c] of best.cells) for (const [si] of cellSlots[r+','+c]) { if (si !== best.i && !assign[si] && !cands(slots[si]).length) { ok = false; break; } }
      if (ok && solve()) return true;
      used.delete(w); assign[best.i] = null;
      best.cells.forEach(([r,c], k) => letters[r][c] = prev[k]);
    }
    return false;
  }
  if (!solve()) return null;
  return { grid: g.map((row, r) => row.map((b, c) => b ? '#' : letters[r][c]).join('')), words: slots.map(s => assign[s.i]) };
}

const count = +(process.argv[2] || 14);
const out = [], themeUsed = new Set((process.env.BAN || '').split(',').filter(Boolean));
let attempts = 0;
while (out.length < count && attempts < 4000) {
  attempts++;
  const g = makeTemplate(+(process.env.MINB || 24), +(process.env.MAXB || 32));
  if (!g) continue;
  const res = fill(g, themeUsed, Date.now() + 2500);
  if (!res) continue;
  const med = res.words.filter(w => medSet.has(w));
  const longMed = res.words.filter(w => w.length >= 7);
  longMed.forEach(w => themeUsed.add(w));
  out.push({ grid: res.grid, words: res.words, medical: med.length, total: res.words.length });
  if (process.env.OUT) require('fs').appendFileSync(process.env.OUT, JSON.stringify(out[out.length - 1]) + '\n');
  process.stderr.write(`puzzle ${out.length} after ${attempts} attempts: ${res.words.length} words, ${med.length} medical, theme ${longMed.join(' ')}\n`);
}
process.stdout.write(JSON.stringify(out, null, 1));
