// node select2.js <bank.jsonl> <count> <out.json>
// Picks puzzles with the most medical answers, no repeated theme answers (7+ letters),
// and as little repeated fill as possible; lists answers that still need clues.
const fs = require('fs'), path = require('path');
const MED = require(path.join(__dirname, 'medical.js'));
const GENC = require(path.join(__dirname, 'clues.js'));
const [file, K, out] = process.argv.slice(2);
const rows = fs.readFileSync(path.join(__dirname, file), 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l));
const seen = new Set(), uniq = rows.filter(r => { const k = r.grid.join(''); if (seen.has(k)) return false; seen.add(k); return true; });
const chosen = [], themes = new Set(), used = {};
while (chosen.length < +K) {
  let best = null, bestScore = -1e9;
  for (const r of uniq) {
    if (chosen.includes(r)) continue;
    const th = r.words.filter(w => w.length >= 7);
    if (th.some(w => themes.has(w))) continue;
    const repeats = r.words.filter(w => used[w]).length;
    const score = r.medical * 3 - repeats * 2;
    if (score > bestScore) { bestScore = score; best = r; }
  }
  if (!best) break;
  chosen.push(best); best.words.filter(w => w.length >= 7).forEach(w => themes.add(w)); best.words.forEach(w => used[w] = (used[w] || 0) + 1);
}
fs.writeFileSync(path.join(__dirname, out), JSON.stringify(chosen.map(r => r.grid)));
const all = Object.keys(used).sort();
console.log('chosen', chosen.length, 'of', uniq.length, '| medical each:', chosen.map(r => r.medical).join(' '));
console.log('themes:', [...themes].join(' '));
console.log('NEED (' + all.filter(w => !MED[w] && !GENC[w]).length + '):', all.filter(w => !MED[w] && !GENC[w]).join(' '));
