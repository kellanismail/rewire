// Exports all three crossword banks (5x5 Mini, 11x11 Daily, 13x13 Challenge) with clues for every answer.
const fs = require('fs'), path = require('path');
const MED = require(path.join(__dirname, 'medical.js'));
const C = Object.assign({}, require('./clues.js'), require('./clues2.js'));
const banks = { mini: 'chosen5.json', daily: 'chosen.json', challenge: 'chosen13.json' };
const answers = g => { const out = [], N = g.length;
  for (let r = 0; r < N; r++) for (const m of g[r].matchAll(/[A-Z]{2,}/g)) out.push(m[0]);
  for (let c = 0; c < g[0].length; c++) { const col = g.map(row => row[c]).join(''); for (const m of col.matchAll(/[A-Z]{2,}/g)) out.push(m[0]); }
  return out; };
const out = {}, used = new Set(), missing = new Set();
for (const [k, f] of Object.entries(banks)) {
  out[k] = JSON.parse(fs.readFileSync(path.join(__dirname, f), 'utf8'));
  out[k].forEach(g => answers(g).forEach(w => { used.add(w); if (!(MED[w] || C[w])) missing.add(w); }));
}
if (missing.size) { console.error('MISSING:', [...missing].join(' ')); process.exit(1); }
const clues = {}; [...used].sort().forEach(w => clues[w] = MED[w] || C[w]);
const js = `const XW_BANKS = ${JSON.stringify(out)};\nconst XW_CLUES = ${JSON.stringify(clues)};\n`;
fs.writeFileSync(path.join(__dirname, 'banks.js'), js);
console.log(Object.entries(out).map(([k, v]) => `${k}: ${v.length}`).join(' | '), '| answers', used.size, '| bytes', js.length);
