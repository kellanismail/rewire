// Turns the chosen grids plus clues into a JS snippet for the app, and checks every answer has a clue.
const fs = require('fs'), path = require('path');
const MED = require(path.join(__dirname, 'medical.js'));
const GENC = require(path.join(__dirname, 'clues.js'));
const grids = JSON.parse(fs.readFileSync(path.join(__dirname, 'chosen.json'), 'utf8'));
const answers = g => {
  const out = [], N = g.length;
  for (let r = 0; r < N; r++) for (const m of g[r].matchAll(/[A-Z]{2,}/g)) out.push(m[0]);
  for (let c = 0; c < N; c++) { const col = g.map(row => row[c]).join(''); for (const m of col.matchAll(/[A-Z]{2,}/g)) out.push(m[0]); }
  return out;
};
const used = new Set(), missing = [];
grids.forEach(g => answers(g).forEach(w => { used.add(w); if (!(MED[w] || GENC[w])) missing.push(w); }));
if (missing.length) { console.error('MISSING CLUES:', [...new Set(missing)].join(' ')); process.exit(1); }
const clues = {}; [...used].sort().forEach(w => clues[w] = MED[w] || GENC[w]);
const js = `const XW_BANK = ${JSON.stringify(grids)};\nconst XW_CLUES = ${JSON.stringify(clues)};\n`;
fs.writeFileSync(path.join(__dirname, 'bank.js'), js);
console.log('puzzles', grids.length, '| clued answers', used.size, '| bytes', js.length);
