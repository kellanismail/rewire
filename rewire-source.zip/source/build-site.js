// Lives in source/. Turns source/rewire.html (the version published on Claude) into the GitHub Pages site files at the repository root:
//   index.html                 standalone page (doctype, charset, mobile viewport, icons, install support)
//   manifest.webmanifest  lets phones and computers install Rewire as an app
//   sw.js                      service worker: works offline, always fetches the newest index.html when online
// Icons (icon-192.png, icon-512.png, apple-touch-icon.png) live at the repository root already.
// Run from anywhere: node source/build-site.js
const fs = require('fs'), path = require('path');
const SITE = path.join(__dirname, '..');   // the repository root, where GitHub Pages serves from
const src = fs.readFileSync(path.join(__dirname, 'rewire.html'), 'utf8');
const version = (src.match(/const APP_VERSION = '([^']+)'/) || [, 'dev'])[1];
const body = src
  .replace(/^<title>[^<]*<\/title>\s*/, '')
  .replace(/<meta name="claude:viewport-fit-sides"[^>]*>\s*/, '');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Rewire</title>
<meta name="description" content="Rewire: daily brain games built on real neuroscience tasks, with medical puzzles, cases and a progress tracker.">
<meta name="theme-color" content="#7B5CE6">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" type="image/png" sizes="192x192" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Rewire">
<style>
/* the small reset Claude's viewer normally supplies */
:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
body{margin:0;font-size:14px}
img{max-width:100%}
[hidden]{display:none!important}
</style>
</head>
<body>
${body}
<script>
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
</script>
</body>
</html>
`;

const manifest = {
  name: 'Rewire',
  short_name: 'Rewire',
  description: 'Daily brain games built on real neuroscience tasks.',
  start_url: './',
  scope: './',
  display: 'standalone',
  background_color: '#DDF0FF',
  theme_color: '#7B5CE6',
  icons: [
    { src: 'icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
  ]
};

const sw = `// Rewire service worker, version ${version}.
// The page itself is network-first, so players get updates as soon as they're online;
// everything else is cached so the app also works offline.
const CACHE = 'rewire-${version}';
const CORE = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(r => { const copy = r.clone(); caches.open(CACHE).then(c => c.put('./index.html', copy)); return r; })
      .catch(() => caches.match('./index.html')));
    return;
  }
  const cacheable = url.origin === location.origin || url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (!cacheable) return;
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => {
    if (r.ok || r.type === 'opaque') { const copy = r.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return r;
  })));
});
`;

fs.mkdirSync(SITE, { recursive: true });
fs.writeFileSync(path.join(SITE, 'index.html'), html);
fs.writeFileSync(path.join(SITE, 'manifest.webmanifest'), JSON.stringify(manifest, null, 2));
fs.writeFileSync(path.join(SITE, 'sw.js'), sw);
console.log(`built version ${version}: index.html ${html.length} bytes, manifest.webmanifest, sw.js`);
